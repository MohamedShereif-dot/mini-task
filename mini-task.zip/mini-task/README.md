# NestJS Auth Mini-Task

Hi! This is my submission for the NestJS authentication mini-task. 

I've implemented the JWT-based authentication flow using Passport, covering the required signup, login, protected profile, and public health routes. 

## How to run it

Make sure you have Node.js installed, then run:

```bash
npm install
npm run start:dev
```

## A few notes on the implementation

- **Storage:** As suggested in the task requirements, I used a simple in-memory array to store the users. Because of this, restarting the development server will wipe the saved users, so you'll need to hit the `/signup` endpoint again after a restart.
- **Security:** Passwords are hashed using `bcrypt` before saving, and the routes ensure the password is never returned in any JSON response.
- **Validation:** I used `class-validator` DTOs to enforce valid emails and a minimum password length.
- **Guards:** The `JwtAuthGuard` is registered globally. To keep the `/health` route open, I created a custom `@Public()` decorator that the guard checks for using Reflector. 

## Testing the API

To save you some time setting up requests, I published my Postman collection. You can view the docs and import the requests directly into your Postman app from this link:

https://documenter.getpostman.com/view/35292440/2sBYB4LSLz

**Quick test flow:**
1. Send a `POST` to `/auth/signup` to create your user.
2. Send a `POST` to `/auth/login` to get the JWT access token.
3. Send a `GET` to `/auth/profile` using the token as a Bearer token.
4. Send a `GET` to `/health` to see the public route working.

Thanks for taking the time to review my code
